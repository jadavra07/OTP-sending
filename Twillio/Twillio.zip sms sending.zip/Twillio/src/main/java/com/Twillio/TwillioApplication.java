package com.Twillio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwillioApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwillioApplication.class, args);
	}

}
