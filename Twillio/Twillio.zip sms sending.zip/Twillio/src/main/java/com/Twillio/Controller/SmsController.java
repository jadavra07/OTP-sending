package com.Twillio.Controller;


import com.Twillio.Service.SmsService;
import com.Twillio.payload.SmsRequestDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/sms")
public class SmsController {

    private final SmsService smsService;

    @Autowired
    public SmsController(SmsService smsService) {
        this.smsService = smsService;
    }

    @PostMapping("/send")
    public ResponseEntity<String> sendSms(@RequestBody SmsRequestDto smsRequestDto) {
        smsService.sendSms(smsRequestDto.getTo(), smsRequestDto.getMessage());
        return new ResponseEntity<>("Message is Send", HttpStatus.OK);
    }
}
